__version__ = '2.0.1'

from .fbmq import *
from . import attachment as Attachment
from . import template as Template